package com.labs.sboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbootRestLabsApplicationTests {

	@Test
	void contextLoads() {
	}

}
